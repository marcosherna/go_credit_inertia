//Estado de Mora 0-Pendiente 1-Pagado 2-Saltado
const estadoCuota = [
    { value: 0, text: 'Pendiente', color : 'red' },
    { value: 1, text: 'Pagado',  color : 'green' },
    { value: 2, text: 'Saltado',  color : 'blue' },
];


export default {
    estadoCuota,
};